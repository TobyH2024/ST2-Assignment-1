from tkinter import *

class KochSnowflake:
    def __init__(self):

        window = Tk()  # Create a window
        window.title("Koch Snowflake")  # Set a title

        self.width = 500
        self.height = 500
        self.canvas = Canvas(window,
                             width=self.width, height=self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window)  # Create and add a frame to window
        frame1.pack()

        Label(frame1,
              text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable=self.order,
                      justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake",
               command=self.display).pack(side=LEFT)

        window.mainloop()  # Create an event loop

    def display(self):

        self.canvas.delete("line")
        p1 = [self.width / 2, 100]
        p2 = [100, self.height - 100]
        p3 = [self.width - 100, self.height - 100]
        order = int(self.order.get())
        self.displayFlakes(order, p1, p2)
        self.displayFlakes(order, p2, p3)
        self.displayFlakes(order, p3, p1)

    def displayFlakes(self, order, p1, p2):

        if order == 0:  # Base condition
            self.drawLine(p1, p2)
        else:
            # Divide edge into thirds
            q1 = [(2 * p1[0] + p2[0]) / 3, (2 * p1[1] + p2[1]) / 3]
            q2 = [(p1[0] + 2 * p2[0]) / 3, (p1[1] + 2 * p2[1]) / 3]

            # Get the direction of the middle third line
            dx = q2[0] - q1[0]
            dy = q2[1] - q1[1]

            # Use midpoint of q1 and q2, then shift  to get peak
            mid = self.midpoint(q1, q2)
            peak = [
                mid[0] - dy * (3 ** 0.5 / 2),
                mid[1] + dx * (3 ** 0.5 / 2)
            ]

            # repeat for all 4 sub edges
            self.displayFlakes(order - 1, p1,   q1)
            self.displayFlakes(order - 1, q1,   peak)
            self.displayFlakes(order - 1, peak, q2)
            self.displayFlakes(order - 1, q2,   p2)

    def drawLine(self, p1, p2):

        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags="line")

    # Return the midpoint between two points
    def midpoint(self, p1, p2):

        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p


KochSnowflake()  # Create GUI