import random
import timeit


# RECURSION
# At its core, recursion involves solving a problem
# by breaking it down into smaller, more manageable instances of the same problem.

# BASIC RECURSION EXAMPLE
def sum_of_natural_numbers(n):
    if n == 1:
        return 1 # Base case
    else:
        return n + sum_of_natural_numbers(n - 1) # Recursive case

# Example usage:
result = sum_of_natural_numbers(100)  # Calculates 1 + 2 + 3 + 4 + 5
print(f"The sum of the first 5 natural numbers is {result}")

#Iterative Loop
def sum_of_natural_numbers_loop(n):
    numSum = 0
    for i in range(n):
        numSum = numSum + (n-i)
    return numSum
num = 100
print(f"Sum of the first {num} natural numbers with Iterative Loop is: {(sum_of_natural_numbers_loop(num))}")



# RECURSIVELY CALCULATING FIBONACCI SEQUENCE (more difficult example)
# f(n) = f(n - 1) + f(n - 2)
def fibonacci(n):
    if n <= 0:
        return 0 # Base case
    elif n == 1:
        return 1 # Base case
    else:
        return fibonacci(n - 1) + fibonacci(n - 2) # Recursive case

# Example usage:
result = fibonacci(14)  # Calculates the 7th Fibonacci number (1, 1, 2, 3, 5, 8, 13, ...)
print(f"The 14th Fibonacci number is {result}")

#Iterative loop
def fibonacci_loop(n):
    beforeNum = 0
    currentNum = 1
    for i in range(n-1):
        num = currentNum
        currentNum = beforeNum + currentNum
        beforeNum = num
    return currentNum
num = 14
print(f"Using an Iterative loop the Fibonacci number {num} is: {(fibonacci_loop(num))}")



# CHALLENGE: Use recursion to calculate the factorial.
def factorial(n):
    """
    Recursive function to calculate the factorial of a non-negative integer.

    Args:
    n (int): Non-negative integer for which factorial is calculated.

    Returns:
    int: Factorial of the input integer.
    """
    if n == 0:
        return 1  # Base case: factorial of 0 is 1
    else:
        return n * factorial(n - 1)  # Recursive case: n! = n * (n-1)!

# Example usage:
num = 14
result = factorial(num)
print(f"The factorial of {num} is {result}")

# Iterative factorial
def factorial_loop(n):
    factNum = 1
    for i in range(1, n+1):
        factNum = factNum * i
    return factNum

num = 1
print(f"Using an iterative loop the factorial of {num} is {factorial_loop(num)}")

