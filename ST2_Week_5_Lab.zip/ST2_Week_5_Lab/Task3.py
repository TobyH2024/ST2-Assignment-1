
count = 0
n = 0
def main():
    global n
    n = eval(input("Enter number of disks: "))
    # Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')
# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global count

    if n == 1: # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        count += 1
        return
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        moveDisks(n - 1, auxTower, toTower, fromTower)
        count += 1
main() # Call the main function
print(f"Number of disks is: {n}")
print(f"\nThe total number of moves is: {count}")

