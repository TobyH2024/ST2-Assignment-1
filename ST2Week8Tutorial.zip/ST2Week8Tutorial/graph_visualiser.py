# === graph_visualizer.py ===
from graph import Graph
import tkinter as tk
# This code was adapted from the 'Python Tkinter: Creating a custom input dialog' page available at:
# https://www.w3resource.com/python-exercises/tkinter/python-tkinter-dialogs-and-file-handling-exercise-5.php
# Accessed 09/04/2026
import tkinter.simpledialog as simpledialog
import math


class GraphVisualizer(tk.Tk):
    def __init__(self, graph):
        super().__init__()
        self.title("Graph Visualizer")
        self.graph = graph
        self.canvas = tk.Canvas(self, width=500, height=400, bg='white')  # [CHANGED] Width 400->500 for more room
        self.canvas.pack()
        self.vertex_positions = {}

        # Create button frame
        buttonFrame = tk.Frame(self)
        buttonFrame.pack()

        # Button Add Vertex
        self.addVertBut = tk.Button(buttonFrame, text="Add Vertex", command=self.add_vertex)
        self.addVertBut.pack(side=tk.LEFT, padx=5, pady=5)

        # Button Add Edge
        self.addEdgeBut = tk.Button(buttonFrame, text="Add Edge", command=self.add_edge)
        self.addEdgeBut.pack(side=tk.LEFT, padx=5, pady=5)

        # Button Remove Vertex
        self.delVertBut = tk.Button(buttonFrame, text="Remove Vertex", command=self.remove_vertex)
        self.delVertBut.pack(side=tk.LEFT, padx=5, pady=5)

        # Button Remove Edge
        self.delEdgeBut = tk.Button(buttonFrame, text="Remove Edge", command=self.remove_edge)
        self.delEdgeBut.pack(side=tk.LEFT, padx=5, pady=5)

        traversal_frame = tk.Frame(self)
        traversal_frame.pack()

        tk.Button(traversal_frame, text="Run BFS", command=self.run_bfs).pack(side=tk.LEFT, padx=5, pady=5)
        tk.Button(traversal_frame, text="Run DFS", command=self.run_dfs).pack(side=tk.LEFT, padx=5, pady=5)

        self.draw_graph()

    def draw_graph(self, highlight=None):

        self.canvas.delete("all")
        radius = 20
        spacing = 150
        n = len(self.graph.graph)
        if n == 0:
            return
        angle_gap = 360 / n
        center_x, center_y = 250, 200

        # Position each vertex evenly around a circle
        for i, v in enumerate(self.graph.graph):
            angle = i * angle_gap
            x = center_x + spacing * math.cos(math.radians(angle))
            y = center_y + spacing * math.sin(math.radians(angle))
            self.vertex_positions[v] = (x, y)

        # Draw edges first so vertex circles sit on top
        for v in self.graph.graph:
            x1, y1 = self.vertex_positions[v]
            for nbr in self.graph.graph[v]:
                x2, y2 = self.vertex_positions[nbr]

                self.canvas.create_line(x1, y1, x2, y2,
                                        arrow=tk.LAST if self.graph.directed else None)
                if self.graph.weighted:
                    w = self.graph.weights.get((v, nbr), '')
                    mid_x = (x1 + x2) / 2
                    mid_y = (y1 + y2) / 2
                    self.canvas.create_text(mid_x, mid_y, text=str(w), fill="red")

        # Draw vertex circles and
        for v in self.graph.graph:
            x, y = self.vertex_positions[v]
            # Highlighted vertices are drawn orange; others are lightblue
            colour = 'orange' if (highlight and v in highlight) else 'lightblue'
            self.canvas.create_oval(x - radius, y - radius, x + radius, y + radius,
                                    fill=colour)
            self.canvas.create_text(x, y, text=str(v))

    def _animate_traversal(self, order, label):

        visited_so_far = []

        def step(i):
            if i >= len(order):
                # print vertex order
                print(f"{label}: {' -> '.join(str(v) for v in order)}")
                return
            visited_so_far.append(order[i])
            self.draw_graph(highlight=set(visited_so_far))
            print(f"{label} visiting: {order[i]}")

            self.after(600, lambda: step(i + 1))  # complete next step after 1000 msS

        step(0)

    def run_bfs(self):

        start = simpledialog.askstring("BFS", "Start vertex:", parent=self)
        if start is None:
            return
        if start not in self.graph.graph:
            print(f"Vertex '{start}' not in graph.")
            return
        order = self.graph.bfs(start)  # bfs() already exists in Graph
        self._animate_traversal(order, "BFS")

    def run_dfs(self):

        start = simpledialog.askstring("DFS", "Start vertex:", parent=self)
        if start is None:
            return
        if start not in self.graph.graph:
            print(f"Vertex '{start}' not in graph.")
            return
        order = self.graph.dfs(start)  # dfs() already exists in Graph
        self._animate_traversal(order, "DFS")

    def add_vertex(self):

        name = simpledialog.askstring("Add Vertex", "Vertex name:", parent=self)
        if name is None:
            return
        self.graph.add_vertex(name)
        self.draw_graph()
        print(f"Added vertex '{name}'.")

    def add_edge(self):

        v1 = simpledialog.askstring("Add Edge", "From vertex:", parent=self)
        if len(v1) < 1:
            return
        v2 = simpledialog.askstring("Add Edge", "To vertex:", parent=self)
        if len(v2) < 1:
            return
        weight = 0
        if self.graph.weighted:
            w_str = simpledialog.askstring("Add Edge", "Weight:", parent=self)
            if len(w_str) > 0:
                try:
                    weight = int(w_str)
                except ValueError:
                    print("Invalid weight")
                    return
        self.graph.add_edge(v1, v2, weight)
        self.draw_graph()
        print(f"Added edge '{v1}' -> '{v2}'")

    def remove_vertex(self):

        name = simpledialog.askstring("Remove Vertex", "Vertex name:", parent=self)
        if name is None:
            return
        self.graph.remove_vertex(name)
        self.draw_graph()

    def remove_edge(self):

        vert1 = simpledialog.askstring("Remove Edge", "From vertex:", parent=self)
        if vert1 is None:
            return
        vert2 = simpledialog.askstring("Remove Edge", "To vertex:", parent=self)
        if vert2 is None:
            return
        self.graph.remove_edge(vert1, vert2)
        self.draw_graph()
        (f"Removed edge '{vert1}' -> '{vert2}'.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    g = Graph(directed=True, weighted=True)
    g.add_vertex('A')
    g.add_vertex('B')
    g.add_vertex('C')
    g.add_edge('A', 'B', 10)
    g.add_edge('B', 'C', 20)
    g.add_edge('C', 'A', 30)

    app = GraphVisualizer(g)
    app.mainloop()