#graph_tester.py
from graph import Graph
# Basic undirected graph tests
g = Graph()
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()


# Directed graph tests
g = Graph(directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B')
g.add_edge('B', 'C')

g.print_graph()
print()

# Weighted graph tests
g = Graph(weighted=True, directed=True)
g.add_vertex('A')
g.add_vertex('B')
g.add_vertex('C')

g.add_edge('A', 'B', 15)
g.add_edge('B', 'C', 34)

g.print_graph()


# Removal tests
print()
print("Directed Graph Removal Test")

# directed graph
gT = Graph(directed=True)
gT.add_vertex('A')
gT.add_vertex('B')
gT.add_vertex('C')

gT.add_edge('A', 'B')
gT.add_edge('B', 'C')

gT.print_graph()

gT.remove_edge('A', 'B')

gT.print_graph()
gT.add_edge('A', 'B')
gT.remove_vertex('C')

gT.print_graph()
print()
print('Undirected Graph Removal Test')

removal_test = Graph()
removal_test.add_vertex('A')
removal_test.add_vertex('B')
removal_test.add_vertex('C')

removal_test.add_edge('A', 'B')
removal_test.add_edge('B', 'C')

removal_test.print_graph()

removal_test.remove_edge('A', 'B')

removal_test.print_graph()

removal_test.remove_vertex('C')

removal_test.print_graph()
print()


# BFS on the graph from Activity 1
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)

# BFS 4 Vertices and extra edge
print("BFS starting from vertex 'A' with 4 vertices:")
BFS = Graph(directed=True)
BFS.add_vertex('A')
BFS.add_vertex('B')
BFS.add_vertex('C')
BFS.add_vertex('D')

BFS.add_edge('A', 'B')
BFS.add_edge('B', 'C')
BFS.add_edge('C', 'D')
BFS.add_edge('D', 'B')


BFS.print_graph()

visited_bfs2 = BFS.bfs('A')
print("Visited vertices in BFS order:", visited_bfs2)

# DFS on the same graph
print("DFS starting from vertex 'A':")
BFS.print_graph()
visited_dfs = BFS.dfs('A')
print("Visited vertices in DFS order:", visited_dfs)

# DFS Branched graph with cycles
print("DFS starting from vertex 'A' Branches and Cycles:")
DFS = Graph(directed=True)
DFS.add_vertex('A')
DFS.add_vertex('B')
DFS.add_vertex('C')
DFS.add_vertex('D')
DFS.add_vertex('E')

DFS.add_edge('A', 'B')
DFS.add_edge('B', 'C')
DFS.add_edge('B', 'D')
DFS.add_edge('B', 'E')
DFS.add_edge('C', 'D')
DFS.add_edge('C', 'E')
DFS.add_edge('D', 'B')
DFS.add_edge('D', 'E')


DFS.print_graph()

visited_dfs2 = DFS.dfs('A')
print("Visited vertices in DFS order:", visited_dfs2)


#cycle detection in undirected graphs
# Create graph with a cycle
cycle_graph = Graph(directed=False)
for v in ['A', 'B', 'C']:
    cycle_graph.add_vertex(v)
cycle_graph.add_edge('A', 'B')
cycle_graph.add_edge('B', 'C')
cycle_graph.add_edge('C', 'A')  # Closing the cycle

cycle_graph.print_graph()
print("Does cycle_graph have a cycle? ", cycle_graph.has_undirected_cycle())

# Create graph without a cycle
acyclic_graph = Graph(directed=False)
for v in ['X', 'Y', 'Z']:
    acyclic_graph.add_vertex(v)
acyclic_graph.add_edge('X', 'Y')
acyclic_graph.add_edge('Y', 'Z')

acyclic_graph.print_graph()
print("Does acyclic_graph have a cycle? ", acyclic_graph.has_undirected_cycle())

# Create weighted directed graph
wg = Graph(directed=True, weighted=True)
for v in ['A', 'B', 'C']:
    wg.add_vertex(v)
wg.add_edge('A', 'B', weight=15)
wg.add_edge('B', 'C', weight=34)
wg.add_edge('A', 'C', weight=50)
print("Weighted Directed Graph:")
wg.print_graph()



